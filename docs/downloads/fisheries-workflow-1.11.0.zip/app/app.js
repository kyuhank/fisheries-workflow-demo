const payload = JSON.parse(document.getElementById("demo-payload").textContent);
const $ = (id) => document.getElementById(id);
const publicExample = !!payload.saved?.outputs?.extract?.output?.sets?.[0]?.stratum;
$("filter").closest("label").hidden = publicExample;
let planVersion = 0,
  jobs = payload.jobs,
  records = {},
  states = {},
  plan = null;
let selected = "submission",
  executionScope = "workflow",
  settingsIntent = false,
  busy = false,
  ready = false,
  currentOutput = null,
  latestRun = "",
  selectedTask = "data";
let mode = "cloud";
const modeStates = {};
let cloudReady = false, unresolvedLive = false;
let liveExecutionLink = "";
let completedRun = null, modeVersion = 0;
let correctionPending = false;
let activities = {}, dispatchPending = false;
let workspaceView = "tasks", jobStatusFilter = "";
// Dependency browsing is independent of the starting job and its execution plan.
let dependencySelection = "prepare_a";
let waitingTransfer = null;
let confirmingTransfer = false;
let runRequested = false;
const byKey = Object.fromEntries(jobs.map((job) => [job.key, job]));
const jobNumbers = Object.freeze(Object.fromEntries(
  jobs.map((job, index) => [job.key, String(index + 1).padStart(2, "0")]),
));
function jobNumber(key) {
  return jobNumbers[key] ? "Job " + jobNumbers[key] : "";
}
function jobLabel(key) {
  return [jobNumber(key), byKey[key]?.title].filter(Boolean).join(" · ");
}
const messages = [];

const cloud = new CloudRun(
  payload.cloud,
  jobs,
  handleEvent,
  (title, message, id) => {
    if (title) status("running", title, message);
    if (id) {
      $("github-run").href = "https://github.com/" + payload.cloud.repository +
        "/actions/runs/" + id;
      liveExecutionLink = $("github-run").href;
      $("github-run").hidden = mode !== "cloud";
    }
  },
);
function call(type, data = {}) {
  if (mode !== "cloud") throw Error("Choose Live run for a new container execution.");
  if (unresolvedLive && ["run", "reset"].includes(type)) {
    throw Object.assign(Error("The previous live run has an unresolved outcome."), {
      executionUnknown: true,
    });
  }
  return cloud.call(type, data);
}

function settings() {
  return {
    last_year: Number($("snapshot").value),
    min_hooks_a: Number($("filter").value),
    growth_rate_2: Number($("growth-rate").value),
    mse_buffer: Number($("mse-buffer").value),
    mse: true,
  };
}

function settingsChanges() {
  const current = settings(), changes = [];
  const previous = records.submission?.settings.last_year;
  if (previous !== undefined && previous !== current.last_year) {
    changes.push({
      start: "submission",
      message: `Data snapshot: ${previous} → ${current.last_year}`,
    });
  }
  const filter = records.cpue_a?.settings.min_hooks;
  if (filter !== undefined && filter !== current.min_hooks_a) {
    changes.push({ start: "cpue_a", message: "CPUE A record selection changed" });
  }
  const assessment = ["assessment_a2", "assessment_b2"].find((key) =>
    records[key] && records[key].settings.r !== current.growth_rate_2
  );
  if (assessment) {
    changes.push({ start: assessment, message: "Assessment growth rate changed" });
  }
  if (records.mse_buffered &&
      (records.mse_buffered.settings.buffer ?? 0.8) !== current.mse_buffer) {
    changes.push({ start: "mse_buffered", message: "MSE catch buffer changed" });
  }
  return changes;
}

function currentStart() {
  // Reverting settings restores the reader's explicit job selection. The planner
  // still adds every changed or missing input, including the other growth-rate fit.
  return settingsIntent && mode !== "saved"
    ? settingsChanges()[0]?.start || selected
    : selected;
}

function displayedPlan() {
  // After completion, keep the work just executed visible. The next run's plan
  // can be smaller once changed settings have been saved in the new records.
  return completedRun || plan;
}

function runStates(run, state) {
  return Object.fromEntries(jobs.map((job) =>
    [job.key, run.includes(job.key) ? state : records[job.key] ? "retained" : "waiting"]));
}

function status(kind, title, message) {
  $("saved-fallback").hidden = true;
  $("retry-connection").hidden = true;
  $("status").className = "status " + kind;
  $("status-title").textContent = title;
  $("status-message").textContent = message;
  $("status-icon").className = "status-icon" +
    (kind === "running" ? " spinner" : "");
  $("status-icon").replaceChildren();
  if (kind !== "running") {
    $("status-icon").append(
      lineIcon(
        kind === "failed" ? "alert" : kind === "complete" ? "check" : "clock",
      ),
    );
  }
}

function affectedByChange(key) {
  return plan?.changed.includes(key) ||
    byKey[key].parents.some(affectedByChange);
}

function stageStatus(key) {
  if (!busy && mode !== "saved" && records[key] && affectedByChange(key)) {
    return "outdated";
  }
  if (states[key]) return states[key];
  if (!records[key]) return "waiting";
  return records[key].run_id === latestRun ? "complete" : "retained";
}

const labels = {
  waiting: "Waiting",
  running: "Running",
  complete: "Complete",
  retained: "Retained",
  failed: "Failed",
  unconfirmed: "Status unavailable",
  returned: "Correction",
  handover: "Awaiting file",
  received: "Received",
  outdated: "Inputs changed",
};
const symbols = {
  waiting: "clock",
  complete: "check",
  retained: "restore",
  failed: "alert",
  unconfirmed: "alert",
  returned: "restore",
  handover: "clock",
  received: "check",
  outdated: "restore",
};

function statusSymbol(state) {
  const symbol = uiElement(
    "span",
    "symbol" + (state === "running" ? " spinner" : ""),
  );
  symbol.setAttribute("aria-hidden", "true");
  if (state !== "running") symbol.append(lineIcon(symbols[state] || "clock"));
  return symbol;
}

function statusLabel(key) {
  return activities[key] === "resubmit" && stageStatus(key) === "running"
    ? "Resubmit"
    : labels[stageStatus(key)];
}

function badge(key) {
  const state = stageStatus(key), span = document.createElement("span");
  span.className = "state";
  span.append(
    statusSymbol(state),
    document.createTextNode(statusLabel(key) || state),
  );
  return span;
}

function selectJob(key, scope = "workflow") {
  selected = key;
  executionScope = scope;
  settingsIntent = false;
  selectedTask = byKey[key].module;
  if (!busy && mode !== "saved") {
    completedRun = null;
    return refreshPlan();
  } else render();
}

function canRequestRun() {
  return ready && !busy && !runRequested && mode !== "saved";
}

async function runFromJob(key, scope = "job") {
  if (!byKey[key] || !canRequestRun()) return;
  const executionMode = mode;
  runRequested = true;
  render();
  const planned = await selectJob(key, scope);
  runRequested = false;
  if (!planned || mode !== executionMode || currentStart() !== key || executionScope !== scope) {
    render();
    return;
  }
  if ($("output-dialog").open) $("output-dialog").close();
  return $("run").onclick();
}

function jobRunButton(key) {
  const button = uiElement("button", "run-job", "Run");
  button.dataset.runJob = key;
  button.disabled = !canRequestRun();
  button.hidden = mode === "saved";
  button.setAttribute("aria-label", "Run " + byKey[key].title);
  button.title = "Run only this job. Prepare missing or changed inputs first.";
  button.onclick = () => runFromJob(key);
  return button;
}

function jobNode(node, colour, path) {
  const key = node.key, job = byKey[key], state = stageStatus(key);
  const inPath = mode === "saved" || path?.run.includes(key), database = key === "database";
  const card = svgElement("g", {
    class: "job workflow-node " + state +
      (currentStart() === key ? " selected" : "") +
      (dispatchPending && key === plan?.run[0] ? " queued-start" : "") +
      (inPath ? " in-path" : " outside-path"),
    transform: `translate(${node.x} ${node.y})`,
    "data-job": key,
    "data-activity": activities[key] || "",
    role: "button",
    tabindex: 0,
    "aria-label": job.title + ": " + (statusLabel(key) || state) +
      ". Select starting job.",
  });
  card.style.setProperty("--accent", colour);
  card.onclick = () => selectJob(key);
  card.onkeydown = (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      selectJob(key);
    }
  };
  const w = node.width, h = node.height;
  const shape = database
    ? svgElement("path", {
      d: `M 0 13 A ${w / 2} 13 0 0 1 ${w} 13 V ${h - 13} A ${
        w / 2
      } 13 0 0 1 0 ${h - 13} Z`,
    })
    : svgElement("rect", { width: w, height: h, rx: 11 });
  const outline = shape.cloneNode();
  outline.setAttribute("class", "node-outline");
  shape.setAttribute("class", "node-shape");
  card.append(outline, shape);
  if (database) {
    card.append(
      svgElement("ellipse", {
        cx: w / 2,
        cy: 13,
        rx: w / 2,
        ry: 13,
        class: "node-cap",
      }),
    );
  }

  const titles = {
    submission: ["Data", "submission"],
    cpue_a: ["CPUE analysis", "A"],
    cpue_b: ["CPUE analysis", "B"],
    cpue_summary: ["Results", "summary"],
    assessment_a1: ["Assessment", "A1"],
    assessment_a2: ["Assessment", "A2"],
    assessment_b1: ["Assessment", "B1"],
    assessment_b2: ["Assessment", "B2"],
    assessment_summary: ["Results", "summary"],
    assessment_report: ["Assessment", "report"],
  };
  const lines = titles[key] || [node.title];
  const titleY = database ? 44 : 26;
  const title = svgElement("text", { x: 14, y: titleY, class: "node-title" });
  for (const [index, line] of lines.entries()) {
    const part = svgElement("tspan", { x: 14, y: titleY + index * 24 });
    part.textContent = line;
    title.append(part);
  }
  card.append(title);
  const statusY = titleY + (lines.length - 1) * 24 + 26;
  const status = svgElement("g", {
    class: "node-status",
    transform: `translate(14 ${statusY - 12})`,
  });
  if (state === "running") {
    const spinner = svgElement("circle", {
      cx: 7,
      cy: 7,
      r: 5.5,
      class: "node-spinner",
    });
    if (!matchMedia("(prefers-reduced-motion: reduce)").matches) {
      spinner.append(
        svgElement("animateTransform", {
          attributeName: "transform",
          type: "rotate",
          from: "0 7 7",
          to: "360 7 7",
          dur: "1s",
          repeatCount: "indefinite",
        }),
      );
    }
    status.append(spinner);
  } else {
    const icon = lineIcon(symbols[state] || "clock");
    icon.setAttribute("class", "node-status-icon");
    icon.setAttribute("width", "14");
    icon.setAttribute("height", "14");
    status.append(icon);
  }
  const statusText = svgElement("text", { x: 22, y: 12 });
  statusText.textContent = statusLabel(key) || state;
  status.append(statusText);
  card.append(status);

  const summary = key.endsWith("_summary");
  if (summary) {
    const subtitle = svgElement("text", {
      x: 14,
      y: statusY + 22,
      class: "node-origin",
    });
    subtitle.textContent = node.subtitle;
    card.append(subtitle);
  }

  const prior = records[key] &&
    ["retained", "waiting", "handover", "outdated"].includes(state);
  const origin = svgElement("text", {
    x: database ? w / 2 : 14,
    y: database ? 17 : h - 11,
    "text-anchor": database ? "middle" : "start",
    class: "node-origin",
  });
  origin.textContent = prior
    ? records[key].run_id
    : summary
    ? ""
    : node.subtitle || "";
  card.append(origin);

  const compactView = key === "qc" || key === "extract";
  const viewWidth = compactView ? 20 : 44;
  const view = svgElement("g", {
    class: "view node-view",
    transform: `translate(${w - viewWidth - 7} ${h - 26})`,
    role: "button",
    tabindex: records[key] ? 0 : -1,
    "aria-disabled": String(!records[key]),
    "aria-label": "View " + job.title + " output",
  });
  view.append(svgElement("rect", { width: viewWidth, height: 22, rx: 4 }));
  const viewText = svgElement("text", {
    x: viewWidth / 2,
    y: 15,
    "text-anchor": "middle",
  });
  viewText.textContent = compactView ? "›" : "View ›";
  view.append(viewText);
  const open = (event) => {
    event.stopPropagation();
    if (records[key]) openOutput(key);
  };
  view.onclick = open;
  view.onkeydown = (event) => {
    event.stopPropagation();
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      open(event);
    }
  };
  card.append(view);
  return card;
}

function svgElement(tag, attributes = {}) {
  const element = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [key, value] of Object.entries(attributes)) {
    element.setAttribute(key, value);
  }
  return element;
}

function roundedRoute(points) {
  let path = `M ${points[0].join(" ")}`;
  for (let i = 1; i < points.length - 1; i++) {
    const a = points[i - 1], b = points[i], c = points[i + 1];
    const before = Math.hypot(b[0] - a[0], b[1] - a[1]),
      after = Math.hypot(c[0] - b[0], c[1] - b[1]);
    const radius = Math.min(9, before / 2, after / 2);
    const entry = b.map((value, axis) =>
      value - (b[axis] - a[axis]) / before * radius
    );
    const leave = b.map((value, axis) =>
      value + (c[axis] - b[axis]) / after * radius
    );
    path += ` L ${entry.join(" ")} Q ${b.join(" ")} ${leave.join(" ")}`;
  }
  return path + ` L ${points.at(-1).join(" ")}`;
}

function renderDiagram() {
  const layout = payload.diagram, path = displayedPlan();
  const svg = svgElement("svg", {
    viewBox: `0 0 ${layout.width} ${layout.height}`,
    class: "workflow-diagram",
    "aria-label": "Data management, CPUE analysis, stock assessment and management strategy evaluation jobs",
  });
  const defs = svgElement("defs");
  for (
    const [name, colour] of Object.entries({
      muted: "#8699a2",
      selected: "#1779a0",
      running: "#bb821f",
      saved: "#548c81",
      failed: "#b95139",
      handover: "#b27b2d",
    })
  ) {
    const marker = svgElement("marker", {
      id: "arrow-" + name,
      markerWidth: 8,
      markerHeight: 8,
      refX: 7,
      refY: 4,
      orient: "auto",
      markerUnits: "userSpaceOnUse",
    });
    marker.append(
      svgElement("path", { d: "M 0 0 L 8 4 L 0 8 Z", fill: colour }),
    );
    defs.append(marker);
  }
  svg.append(defs);
  for (const group of layout.groups) {
    svg.append(
      svgElement("rect", {
        x: group.x,
        y: group.y ?? 42,
        width: group.width,
        height: group.height ?? 580,
        rx: 16,
        fill: group.fill,
        stroke: group.colour,
        "stroke-opacity": .22,
      }),
    );
    const title = svgElement("text", {
      x: group.x + 14,
      y: (group.y ?? 42) - 18,
      fill: group.colour,
      class: "module-title",
    });
    title.textContent = group.title;
    svg.append(title);
  }
  const connections = layout.edges.map((edge) => {
    const inPath = path?.run.includes(edge.from) && path?.run.includes(edge.to);
    const receiving = busy && stageStatus(edge.to) === "running";
    const retained = path?.retained.includes(edge.from) &&
      path?.run.includes(edge.to);
    const awaiting = waitingTransfer?.group.includes(edge.to) &&
      ((waitingTransfer.boundary === "data" && edge.from === "extract" &&
        edge.to.startsWith("cpue_")) ||
        (waitingTransfer.boundary === "cpue" && edge.from.startsWith("cpue_") &&
          edge.to.startsWith("prepare_")) ||
        (waitingTransfer.boundary === "assessment" && edge.to === "mse_prepare" &&
          byKey.mse_prepare.parents.includes(edge.from)));
    const kind = awaiting
      ? "handover"
      : receiving
      ? (retained ? "saved" : "running")
      : !busy && inPath && mode !== "saved"
      ? "selected"
      : "muted";
    return { ...edge, displayKind: kind };
  });
  // Shared routes stay visible when one contributing job is being rerun.
  const priority = { muted: 0, saved: 1, selected: 2, running: 3, handover: 4 };
  connections.sort((left, right) => priority[left.displayKind] - priority[right.displayKind]);
  for (const edge of connections) {
    const kind = edge.displayKind;
    svg.append(
      svgElement("path", {
        d: roundedRoute(edge.points),
        class: `connection ${kind} ${edge.kind}`,
        "data-from": edge.from,
        "data-to": edge.to,
        "marker-end": `url(#arrow-${kind})`,
      }),
    );
  }
  const loop = svgElement("path", {
    d: roundedRoute(layout.return.points),
    class: "connection return-path " +
      (correctionPending ? "failed active" : "muted"),
    "marker-end": "url(#arrow-" + (correctionPending ? "failed" : "muted") +
      ")",
  });
  svg.append(loop);
  if (correctionPending) {
    const text = svgElement("text", { x: 218, y: 287, class: "return-label" });
    for (const [i, line] of ["Correct +", "Resubmit"].entries()) {
      const part = svgElement("tspan", { x: 218, dy: i ? 18 : 0 });
      part.textContent = line;
      text.append(part);
    }
    svg.append(text);
  }
  for (const label of layout.labels) {
    const text = svgElement("text", {
      x: label.x,
      y: label.y,
      class: "edge-label",
    });
    text.textContent = label.text;
    svg.append(text);
  }
  for (const note of layout.notes || []) {
    const text = svgElement("text", {
      x: note.x, y: note.y, class: "diagram-note",
      "text-anchor": note.anchor || "start",
    });
    text.textContent = note.text;
    svg.append(text);
  }
  for (const node of layout.nodes) {
    const group = layout.groups.find((group) =>
      group.key === byKey[node.key].module
    );
    svg.append(jobNode(node, group.colour, path));
  }
  if ($("handover").value === "manual" && mode !== "saved") {
    for (const [boundary, x, y, to] of [
      ["data", 383, 175, "cpue_a"], ["data", 383, 487, "cpue_b"],
      ["cpue", 846, 175, "prepare_a"], ["cpue", 846, 487, "prepare_b"],
      ["assessment", 1282, 670, "mse_prepare"],
    ]) {
      const active = waitingTransfer?.boundary === boundary &&
        waitingTransfer.group.includes(to);
      const group = svgElement("g", {
        class: "handover-marker" + (active ? " active" : ""),
        transform: `translate(${x} ${y})`,
        "data-boundary": boundary,
        "data-to": to,
      });
      group.append(
        svgElement("circle", { r: 15 }),
        svgElement("circle", { cx: 0, cy: -4, r: 3.5 }),
        svgElement("path", { d: "M -7 7 Q -7 0 0 0 Q 7 0 7 7" }),
      );
      const title = svgElement("title");
      title.textContent = (active ? "Confirm file transfer to " : "Manual file transfer to ") +
        byKey[to].title;
      group.append(title);
      svg.append(group);
    }
  }
  $("workflow-view").classList.toggle("is-running", busy);
  $("workflow-view").replaceChildren(svg);
}

const taskGroups = [
  {
    key: "data",
    title: "Data management",
    description: "Submit, check and extract records.",
    icon: "database",
  },
  {
    key: "cpue",
    title: "CPUE analysis",
    description: "Standardise, compare and report indices.",
    icon: "chart",
  },
  {
    key: "assessment",
    title: "Stock assessment",
    description: "Prepare inputs, fit models and report results.",
    icon: "layers",
  },
  {
    key: "mse",
    title: "Management strategy evaluation",
    description: "Test management rules, compare outcomes and report results.",
    icon: "cycle",
  },
];

function uiElement(tag, className = "", text) {
  const element = document.createElement(tag);
  element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function lineIcon(name) {
  const icon = svgElement("svg", {
    viewBox: "0 0 24 24",
    "aria-hidden": "true",
    class: "line-icon",
  });
  const paths = {
    folder: "M3 6h7l2 3h9v11H3Z M3 6V4h7l2 2h9v3",
    list: "M8 6h13M8 12h13M8 18h13M3 6h1M3 12h1M3 18h1",
    dependencies: "M3 9h6v6H3ZM15 3h6v6h-6ZM15 15h6v6h-6ZM9 12h3m0-6v12m0-12h3m-3 12h3",
    database:
      "M4 6c0-4 16-4 16 0s-16 4-16 0m0 0v12c0 4 16 4 16 0V6M4 12c0 4 16 4 16 0",
    chart: "M4 4v16h16M7 15l4-5 4 2 5-7",
    cycle: "M20 9a8 8 0 0 0-14-3L3 9m0-5v5h5m-4 6a8 8 0 0 0 14 3l3-3m0 5v-5h-5",
    layers: "M3 7l9-4 9 4-9 4-9-4m0 5 9 4 9-4M3 17l9 4 9-4",
    file: "M6 3h8l4 4v14H6V3m8 0v5h4M9 12h6m-6 4h6",
    person: "M8 7a4 4 0 1 0 8 0 4 4 0 1 0-8 0M4 21v-2a8 8 0 0 1 16 0v2",
    check: "M5 12l4 4L19 6",
    clock: "M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18M12 7v5l3 2",
    restore: "M4 11a8 8 0 1 1 1 6M4 5v6h6",
    alert: "M12 3l10 18H2L12 3zM12 9v5m0 3v.1",
  };
  icon.append(svgElement("path", { d: paths[name] }));
  return icon;
}

function renderTasks() {
  $("tasks").replaceChildren();
  $("task-count").textContent = taskGroups.length;
  $("job-count").textContent = jobs.length;
  for (const task of taskGroups) {
    const members = jobs.filter((job) => job.module === task.key);
    const active = members.filter((job) => stageStatus(job.key) === "running");
    const awaiting = members.find((job) => stageStatus(job.key) === "handover");
    const failed = members.find((job) => stageStatus(job.key) === "failed");
    const outdated = members.find((job) => stageStatus(job.key) === "outdated");
    const available = members.filter((job) => records[job.key]).length;
    const completed = members.filter((job) => stageStatus(job.key) === "complete").length;
    const reused = members.filter((job) => stageStatus(job.key) === "retained").length;
    const resolved = members.every((job) =>
      ["complete", "retained"].includes(stageStatus(job.key))
    );
    const state = active.length
      ? "running"
      : failed
      ? "failed"
      : awaiting
      ? "handover"
      : outdated
      ? "outdated"
      : resolved
      ? (reused === members.length ? "retained" : "complete")
      : "waiting";
    const button = uiElement(
      "button",
      "task " + task.key + " " + state +
        (selectedTask === task.key ? " active" : ""),
    );
    button.setAttribute("aria-pressed", String(selectedTask === task.key));
    const heading = uiElement("span", "task-card-heading");
    const icon = uiElement("span", "task-icon");
    icon.append(lineIcon(task.icon));
    const name = uiElement("strong", "task-name", task.title);
    const status = uiElement("span", "task-status " + state);
    status.append(statusSymbol(state), document.createTextNode(state === "retained" ? "Reused" : labels[state]));
    heading.append(icon, name, status);
    const description = uiElement("span", "task-description", task.description);
    const responsibility = uiElement("span", "task-responsibility");
    responsibility.append(lineIcon("person"), uiElement("span", "",
      [...new Set(members.map((job) => job.owner))].join(" · ")));
    const progress = uiElement("span", "task-progress");
    progress.setAttribute("aria-hidden", "true");
    for (const job of members) {
      const segment = uiElement("span", stageStatus(job.key));
      segment.title = job.title + ": " + labels[stageStatus(job.key)];
      progress.append(segment);
    }
    const footer = uiElement("span", "task-footer");
    footer.append(
      uiElement("span", "", completed || reused
        ? [completed && `${completed} complete`, reused && `${reused} reused`].filter(Boolean).join(" · ")
        : `${available}/${members.length} outputs available`),
      uiElement("span", "task-open", `${members.length} jobs ›`),
    );
    const activity = uiElement(
      "span",
      "task-activity",
      (active.length > 1
        ? `${active.length} jobs running together`
        : active.length
        ? (activities[active[0].key] === "resubmit"
          ? "Resubmit corrected data"
          : active[0].title)
        : "") ||
        (awaiting ? "Waiting for file transfer" : "") || failed?.title ||
        (outdated ? "Updated inputs need a rerun" : ""),
    );
    activity.hidden = !activity.textContent;
    button.append(heading, description, responsibility, progress, activity, footer);
    button.onclick = () => {
      selectedTask = task.key;
      workspaceView = "jobs";
      jobStatusFilter = "";
      render();
    };
    $("tasks").append(button);
  }
  $("task-title").textContent =
    taskGroups.find((task) => task.key === selectedTask)?.title || "All jobs";
  const activeJobs = jobs.filter((job) => stageStatus(job.key) === "running");
  $("running-count").textContent = activeJobs.length;
  $("workspace-activity").replaceChildren(
    statusSymbol(
      activeJobs.length
        ? "running"
        : waitingTransfer
        ? "handover"
        : busy || !Object.keys(records).length
        ? "waiting"
        : "complete",
    ),
    document.createTextNode(
      activeJobs.length
        ? `${activeJobs.length} running`
        : waitingTransfer
        ? "Awaiting file transfer"
        : busy
        ? "Waiting"
        : Object.keys(records).length
        ? "Results available"
        : "Ready",
    ),
  );
  $("workspace-activity").classList.toggle("running", activeJobs.length > 0);
  $("workspace-activity").classList.toggle("handover", Boolean(waitingTransfer));
  $("tasks").hidden = workspaceView !== "tasks";
  $("task-jobs").hidden = workspaceView !== "jobs";
  $("dependencies-view").hidden = workspaceView !== "dependencies";
  $("workspace-breadcrumb").textContent = workspaceView === "tasks"
    ? "Tasks"
    : workspaceView === "dependencies" ? "Job dependencies"
    : "Tasks / Jobs";
  $("workspace-title").textContent = workspaceView === "tasks"
    ? "Tasks"
    : workspaceView === "dependencies" ? "Follow a job’s connections"
    : $("task-title").textContent;
  $("workspace-description").textContent = workspaceView === "tasks"
    ? "Select a task to see its analyses and results."
    : workspaceView === "dependencies" ? "See the earlier results a job needs and the later analyses that use it."
    : "Open Output for a result or Record for the inputs and versions it used.";
  $("task-filter").value = selectedTask || "";
  $("job-status-filter").value = jobStatusFilter;
  $("show-tasks").classList.toggle("active", workspaceView === "tasks");
  $("show-dependencies").classList.toggle("active", workspaceView === "dependencies");
  $("all-tasks").classList.toggle(
    "active",
    workspaceView === "jobs" && !jobStatusFilter,
  );
  $("running-jobs").classList.toggle(
    "active",
    workspaceView === "jobs" && jobStatusFilter === "running",
  );
}

function jobProgress(job) {
  const state = stageStatus(job.key);
  const pendingInputs = job.parents.filter((key) =>
    !["complete", "retained"].includes(stageStatus(key)));
  const detail = state === "handover" ? "Confirm file transfer to continue"
    : state === "retained" ? "Earlier result kept unchanged"
    : state === "outdated" ? "Rerun with the updated inputs"
    : state === "failed" ? "Open the execution log"
    : state === "unconfirmed" ? "Check Execution before starting another run"
    : state === "waiting" && pendingInputs.length
    ? "After " + byKey[pendingInputs[0]].title + (pendingInputs.length > 1 ? ` + ${pendingInputs.length - 1} more` : "")
    : state === "waiting" ? (busy ? "Inputs available · queued" : "Inputs available")
    : "";
  const label = state === "retained" ? "Reused"
    : state === "waiting" && !pendingInputs.length && !busy ? "Ready"
    : statusLabel(job.key);
  return { state, detail, label };
}

async function openJobRecord(key) {
  await openOutput(key);
  if (currentOutput?.record?.job === key && $("output-dialog").open) {
    document.querySelector('[data-output="record"]').click();
  }
}

function inspectDependencies(key) {
  if (!byKey[key]) return;
  dependencySelection = key;
  renderDependencies();
}

function dependencyCard(key, current) {
  const job = byKey[key], progress = jobProgress(job);
  const task = taskGroups.find((task) => task.key === job.module);
  const colour = payload.diagram.groups.find((group) => group.key === job.module).colour;
  const card = uiElement("article", "dependency-card " + progress.state + (current ? " current" : ""));
  card.dataset.job = key;
  card.dataset.module = job.module;
  card.style.setProperty("--accent", colour);
  const module = uiElement("p", "dependency-module");
  module.append(uiElement("span", "job-number", jobNumber(key)),
    document.createTextNode(" · " + task.title));
  card.append(module);
  const heading = uiElement("h4", "dependency-title");
  if (current) heading.textContent = job.title;
  else {
    const inspect = uiElement("button", "dependency-inspect", job.title);
    inspect.setAttribute("aria-label", "Inspect dependencies of " + job.title);
    inspect.onclick = () => {
      inspectDependencies(key);
      $("dependency-job").focus({ preventScroll: true });
    };
    heading.append(inspect);
  }
  card.append(heading);
  if (current) card.append(uiElement("p", "dependency-description", job.description));
  const progressBadge = badge(key);
  progressBadge.lastChild.textContent = progress.label;
  if (progress.label === "Ready") progressBadge.classList.add("ready");
  card.append(progressBadge);
  if (progress.detail) card.append(uiElement("p", "dependency-progress", progress.detail));
  const owner = uiElement("p", "dependency-owner");
  owner.append(lineIcon("person"), document.createTextNode(job.owner));
  owner.setAttribute("aria-label", "Responsible: " + job.owner);
  card.append(owner);
  const origin = uiElement("div", "dependency-origin");
  origin.append(uiElement("span", "", "Output from"),
    uiElement("span", "run-label", records[key]?.run_id || "No output yet"));
  card.append(origin);
  const actions = uiElement("div", "dependency-actions");
  const output = uiElement("button", "open-output");
  output.append(lineIcon("file"), document.createTextNode("Output"));
  output.disabled = !records[key];
  output.setAttribute("aria-label", "Open " + job.title + " output");
  output.onclick = () => openOutput(key);
  const record = uiElement("button", "open-job-record", "Record");
  record.disabled = !records[key];
  record.setAttribute("aria-label", "Inspect " + job.title + " recorded inputs and versions");
  record.onclick = () => openJobRecord(key);
  actions.append(output, record);
  actions.append(jobRunButton(key));
  card.append(actions);
  return card;
}

function renderDependencies() {
  const picker = $("dependency-job");
  if (!picker.options.length) {
    for (const task of taskGroups) {
      const group = document.createElement("optgroup");
      group.label = task.title;
      for (const job of jobs.filter((job) => job.module === task.key)) {
        const option = uiElement("option", "", jobLabel(job.key));
        option.value = job.key;
        group.append(option);
      }
      picker.append(group);
    }
  }
  const job = byKey[dependencySelection] || jobs[0];
  dependencySelection = job.key;
  picker.value = job.key;
  // These are declared input relationships, not execution-stage barriers or a
  // claim that the latest parent record was consumed by a previous job run.
  const children = jobs.filter((candidate) => candidate.parents.includes(job.key));
  const groups = [
    { role: "inputs", title: "Required inputs", keys: job.parents, empty: "No upstream jobs. This job starts with supplied data." },
    { role: "current", title: "This job", keys: [job.key] },
    { role: "outputs", title: "Uses this output", keys: children.map((child) => child.key), empty: "No downstream jobs. Review or download the output when it is available." },
  ];
  const flow = $("dependency-flow");
  flow.replaceChildren();
  for (const [index, group] of groups.entries()) {
    if (index) {
      const arrow = uiElement("span", "dependency-arrow", "→");
      arrow.setAttribute("aria-hidden", "true");
      flow.append(arrow);
    }
    const section = uiElement("section", "dependency-group dependency-" + group.role);
    section.dataset.group = group.role;
    const heading = uiElement("h3", "dependency-heading", group.title);
    heading.id = "dependency-" + group.role + "-heading";
    if (group.role !== "current") heading.append(uiElement("span", "", group.keys.length));
    section.setAttribute("aria-labelledby", heading.id);
    section.append(heading);
    const cards = uiElement("div", "dependency-cards");
    for (const key of group.keys) cards.append(dependencyCard(key, group.role === "current"));
    if (!group.keys.length) cards.append(uiElement("p", "dependency-empty", group.empty));
    section.append(cards);
    flow.append(section);
  }
  $("dependency-rule").textContent = job.parents.length
    ? `${job.title} needs ${job.parents.length === 1 ? "the required input" : `all ${job.parents.length} required inputs`}. ` +
      (children.length ? `${children.length} ${children.length === 1 ? "job uses" : "jobs use"} its output directly.` : "No jobs use its output directly.")
    : `${job.title} starts this workflow from supplied catch and effort records.`;
}

function renderJobTable() {
  $("job-table-body").replaceChildren();
  for (const job of jobs) {
    if (selectedTask && job.module !== selectedTask) continue;
    if (jobStatusFilter && stageStatus(job.key) !== jobStatusFilter) continue;
    const row = document.createElement("tr");
    const progress = jobProgress(job);
    row.className = stageStatus(job.key) +
      (currentStart() === job.key ? " selected-job" : "");
    row.dataset.job = job.key;
    row.dataset.module = job.module;
    const name = document.createElement("td");
    name.className = "job-name-cell";
    const select = uiElement("button", "job-name", job.title);
    select.onclick = () => openOutput(job.key);
    select.setAttribute("aria-label", "Open " + job.title);
    name.append(uiElement("span", "job-number", jobNumber(job.key)), select);
    const owner = uiElement("td", "job-owner");
    owner.dataset.label = "Responsible";
    const ownerLabel = uiElement("span", "owner-label");
    ownerLabel.append(lineIcon("person"), document.createTextNode(job.owner));
    owner.append(ownerLabel);
    row.append(name, owner);
    const inputs = uiElement("div", "job-inputs");
    inputs.append(uiElement("span", "input-caption", job.parents.length ? "Inputs" : "Supplied catch and effort records"));
    for (const key of job.parents) {
      const input = records[job.key]?.inputs?.[key];
      const earlierVersion = input && (input.run_id !== records[key]?.run_id ||
        input.checksum !== records[key]?.outputs?.["output.json"]);
      const link = uiElement("button", "input-link", jobLabel(key));
      link.dataset.inputJob = key;
      link.disabled = Boolean(earlierVersion);
      link.title = earlierVersion ? "Earlier input version · open this job’s Record"
        : records[key] ? `Inspect input record · ${records[key].run_id}` : "Select this input job";
      link.onclick = () => records[key] ? openJobRecord(key) : openOutput(key);
      inputs.append(link);
    }
    row.firstChild.append(inputs);
    const state = document.createElement("td");
    const progressBadge = badge(job.key);
    progressBadge.lastChild.textContent = progress.label;
    if (progress.label === "Ready") progressBadge.classList.add("ready");
    state.className = "job-progress";
    state.append(progressBadge);
    if (progress.detail) state.append(uiElement("small", "progress-detail", progress.detail));
    row.append(state);
    const origin = document.createElement("td");
    origin.className = "job-origin";
    origin.dataset.label = "Output from";
    origin.append(
      uiElement("span", "run-label", records[job.key]?.run_id || "—"),
    );
    row.append(origin);
    const output = document.createElement("td"),
      button = document.createElement("button");
    button.className = "open-output";
    button.append(lineIcon("file"), document.createTextNode("Output"));
    button.setAttribute("aria-label", "Open " + job.title + " output");
    button.disabled = !records[job.key];
    button.onclick = () => openOutput(job.key);
    const recordButton = uiElement("button", "open-job-record", "Record");
    recordButton.disabled = !records[job.key];
    recordButton.setAttribute("aria-label", "Inspect " + job.title + " recorded inputs and versions");
    recordButton.onclick = () => openJobRecord(job.key);
    output.className = "job-inspect";
    output.append(button, recordButton, jobRunButton(job.key));
    row.append(output);
    $("job-table-body").append(row);
  }
  const count = $("job-table-body").children.length;
  $("task-subtitle").textContent = `${count} ${count === 1 ? "job" : "jobs"}`;
  if (!count) {
    const row = document.createElement("tr"),
      cell = uiElement("td", "empty-jobs", "No jobs in this state.");
    cell.colSpan = 5;
    row.append(cell);
    $("job-table-body").append(row);
  }
}

function render() {
  const start = currentStart();
  renderDiagram();
  renderTasks();
  renderJobTable();
  renderDependencies();
  $("selection-title").textContent = byKey[start].title;
  $("selection-description").textContent = byKey[start].description;
  $("run").disabled = !ready || busy || !plan || mode === "saved";
  $("run").hidden = mode === "saved";
  $("run-workflow").hidden = mode === "saved" || (start === "submission" && executionScope === "workflow");
  $("run-workflow").disabled = !canRequestRun();
  $("run-workflow").textContent = Object.keys(records).length && plan?.changed.length
    ? "Update workflow" : "Run workflow";
  renderOutputRun();
  $("run").textContent = busy
    ? "Running…"
    : executionScope === "job"
    ? "Run this job"
    : start === "submission"
    ? "Run full workflow →"
    : "Run from this job →";
  $("download").disabled = busy || !Object.keys(records).length;
  $("reset").disabled = busy || !ready || mode === "saved";
  $("mode").disabled = busy;
  $("handover").disabled = busy || mode === "saved";
  $("handover-note").hidden = Boolean(waitingTransfer) || mode === "saved" ||
    $("handover").value !== "manual";
  $("handover-help").textContent = $("handover").value === "manual"
    ? "Confirm each file transfer to continue."
    : "Pass recorded inputs automatically.";
  $("revise-cpue").hidden = publicExample || busy || !records.cpue_a;
  $("handover-panel").hidden = !waitingTransfer;
  $("transfer-files").disabled = confirmingTransfer;
  $("connect-workflow").disabled = confirmingTransfer;
  $("transfer-files").textContent = confirmingTransfer
    ? "Confirming transfer…"
    : "Confirm file transfer →";
  const manual = $("handover").value === "manual" && mode !== "saved";
  document.querySelector('[data-tab="jobs"]').textContent = "Orchestration tool";
  document.querySelector('.workspace-brand .eyebrow').textContent = manual ? "Manual handover" : "Orchestration";
  document.querySelector('.workspace-brand strong').textContent = manual ? "Job outputs" : "Analysis workspace";
  document.querySelector('.workspace-nav').setAttribute('aria-label', manual
    ? "Job outputs navigation" : "Orchestration navigation");
  if (manual) $("workspace-description").textContent = workspaceView === "dependencies"
    ? "These connections show the files passed between analysts. Manual handovers require confirmation."
    : "Inspect results and records; confirm a file transfer when an analysis is waiting.";
  renderViewGuide();
  for (const id of ["snapshot", "filter", "growth-rate", "mse-buffer"]) {
    $(id).disabled = busy || mode === "saved";
  }
  $("selection-label").textContent = mode === "saved" || executionScope === "job" ? "Selected job" : "Start from";
  $("hint").textContent = mode === "saved"
    ? "Open a job’s output, then use Inputs & versions to trace its inputs."
    : "Job Run prepares required inputs and stops at that job. Run workflow also updates dependent analyses.";
  if (mode === "saved") {
    $("completion").textContent = `${Object.keys(records).length} saved outputs`;
    $("reuse-message").textContent = "";
  } else if (plan) {
    $("completion").textContent = completedRun
      ? `${completedRun.run.length} completed · ${completedRun.retained.length} retained`
      : `${plan.run.length} jobs to run · ${plan.retained.length} retained`;
    const parentNames = byKey[start].parents.filter((key) =>
      plan.retained.includes(key)
    ).map((key) => `${byKey[key].title} (${records[key]?.run_id})`);
    $("reuse-message").textContent = parentNames.length
      ? "Uses saved inputs: " + parentNames.join(" · ")
      : plan.retained.length
      ? "Other results keep their original run and files."
      : "";
    if (plan.changed.length && start !== "submission") {
      $("reuse-message").textContent +=
        " Missing or changed inputs are rebuilt first.";
    }
  }
}

async function refreshPlan() {
  if (!ready || busy || mode === "saved") return false;
  const version = ++planVersion, executionMode = mode;
  $("run").disabled = true;
  try {
    const next = await call("plan", { start: currentStart(), settings: settings(), scope: executionScope });
    if (version === planVersion && executionMode === mode) {
      plan = next;
      explainChanges();
      render();
      return true;
    }
  } catch (error) {
    if (version === planVersion && executionMode === mode) showError(error);
  }
  return false;
}

function explainChanges() {
  const changes = settingsChanges().map((change) => change.message);
  if (changes.length) {
    status("settings-changed", "New settings · previous results kept",
      changes.join(" · ") + ". Run to update the affected jobs.");
  } else if ($("status").classList.contains("settings-changed")) {
    status("complete", "Previous settings restored", "Saved results match these settings.");
  }
}

function showError(error) {
  const unfinished = new Set([...(plan?.run || []), ...(waitingTransfer?.group || [])]);
  for (const key of unfinished) {
    if (["waiting", "running", "handover", "received"].includes(states[key])) {
      states[key] = error.executionUnknown ? "unconfirmed" : "failed";
      activities[key] = "";
    }
  }
  busy = false;
  dispatchPending = false;
  waitingTransfer = null;
  confirmingTransfer = false;
  if (error.executionUnknown && mode === "cloud") {
    ready = false;
    unresolvedLive = true;
  }
  status("failed", error.executionUnknown ? "Live run status unavailable" : "The analysis stopped",
    error.executionUnknown
      ? "The live run may still be active. " +
        ($("github-run").hidden ? "" : "Open Execution to check it. ") +
        "Keep this page open. Check the execution before starting another run. You can inspect the saved example meanwhile."
      : String(error));
  $("saved-fallback").hidden = mode !== "cloud";
  render();
}

function log(event) {
  const name = byKey[event.job]?.title || "Workflow";
  messages.push(`${name} · ${event.message || event.state}`);
  $("execution-log").textContent = messages.join("\n");
  $("execution-log").scrollTop = $("execution-log").scrollHeight;
}

function handleEvent(event) {
  if (event.state === "session_expired") {
    // Only the live session loses its files; settings and job selection survive.
    if (modeStates.cloud) Object.assign(modeStates.cloud, {
      records: {}, states: {}, latestRun: "", completedRun: null, messages: [],
    });
    if (mode !== "cloud") return;
    records = {};
    completedRun = null;
    latestRun = "";
    waitingTransfer = null;
    confirmingTransfer = false;
    activities = {};
    plan = cloud.plan(currentStart(), settings(), executionScope);
    states = busy ? runStates(plan.run, "waiting") : {};
    $("run-id").textContent = "";
    $("github-run").hidden = true;
    liveExecutionLink = "";
    log({ message: "Temporary live results expired. Missing inputs will be rebuilt." });
    status("running", "Renewing the live session",
      "Your selected job and settings are kept. Expired inputs must be rebuilt.");
    render();
    return;
  }
  if (event.state === "plan") {
    correctionPending = false;
    activities = {};
    waitingTransfer = null;
    confirmingTransfer = false;
    plan = event;
    latestRun = event.run_id;
    $("run-id").textContent = latestRun;
    states = runStates(plan.run, "waiting");
  } else {
    dispatchPending = false;
    if (["running", "handover", "received"].includes(event.state) && event.group) {
      for (const key of event.group) {
        states[key] = event.state;
        activities[key] = "";
      }
    }
    activities[event.job] = event.activity || "";
    if (event.state === "handover") {
      waitingTransfer = { ...event, group: event.group || [event.job] };
      confirmingTransfer = false;
      $("handover-title").textContent = event.boundary === "data"
        ? "Data manager → CPUE analyst"
        : event.boundary === "assessment" ? "Assessment analyst → MSE analyst"
        : "CPUE analyst → Assessment analyst";
      $("handover-message").textContent = "This simulates a file handover between analysts. Confirm it to continue receiving jobs; no upload is needed.";
    } else if (event.state === "received") {
      waitingTransfer = null;
      confirmingTransfer = false;
    }
    if (event.job === "qc" && event.state === "failed") {
      correctionPending = true;
    }
    if (event.job === "submission" && event.state === "returned") {
      states.qc = "waiting";
    }
    if (event.job === "qc" && ["running", "complete"].includes(event.state)) {
      correctionPending = false;
    }
    states[event.job] = event.state;
    if (event.record) records[event.job] = event.record;
    log(event);
    const active = jobs.filter((job) => states[job.key] === "running");
    const groupTitle = active.length > 1
      ? `${active.length} jobs running together`
      : "";
    status(
      event.state === "failed"
        ? "failed"
        : waitingTransfer
        ? "handover"
        : "running",
      waitingTransfer
        ? "File transfer required · click to continue"
        : event.activity === "resubmit"
        ? "Resubmit corrected data"
        : event.state === "returned"
        ? "Correct the submission"
        : groupTitle || byKey[event.job].title,
      waitingTransfer
        ? waitingTransfer.boundary === "cpue"
          ? "Assessment preparation waits for revised CPUE files. CPUE summaries and reports can continue; confirm the transfer below."
          : waitingTransfer.boundary === "assessment"
          ? "MSE preparation waits for assessment files. Assessment summaries and reports can continue; confirm the transfer below."
          : "CPUE analysis waits for extracted data. Confirm the transfer below to continue."
        : groupTitle
        ? active.map((job) => job.title).join(" · ") +
          ". Jobs using these results wait for the group to finish."
        : event.message,
    );
  }
  render();
}
$("run").onclick = async () => {
  if (!canRequestRun() || !plan || $("run").disabled) return;
  const start = currentStart(), runSettings = settings();
  const scope = executionScope;
  // Once dispatched, repeating Run should repeat this stage even after its
  // settings have been saved and no longer differ from the current records.
  selected = start;
  settingsIntent = false;
  ++planVersion;
  busy = true;
  dispatchPending = true;
  correctionPending = false;
  activities = {};
  completedRun = null;
  states = runStates(plan.run, "waiting");
  messages.length = 0;
  $("execution-log").textContent = "";
  status(
    "running",
    "Starting the selected work",
    "Checking saved inputs and the selected settings.",
  );
  render();
  try {
    const result = await call("run", {
      start,
      scope,
      settings: runSettings,
      handover: $("handover").value,
    });
    records = result.records;
    states = runStates(result.run, "complete");
    waitingTransfer = null;
    confirmingTransfer = false;
    completedRun = { run: result.run, retained: result.retained };
    dispatchPending = false;
    busy = false;
    latestRun = result.run_id;
    status(
      "complete",
      "Results are ready",
      `${result.run.length} ${
        result.run.length === 1 ? "job" : "jobs"
      } completed · ${result.retained.length} retained unchanged. Open a job to inspect its output.`,
    );
    await refreshPlan();
    return result;
  } catch (error) {
    showError(error);
    await refreshPlan();
  }
};
$("run-workflow").onclick = () => runFromJob(plan?.changed[0] || "submission", "workflow");
for (const id of ["snapshot", "filter", "growth-rate", "mse-buffer"]) {
  $(id).onchange = () => {
    settingsIntent = true;
    executionScope = "workflow";
    completedRun = null;
    refreshPlan();
  };
}
$("handover").onchange = () => {
  status(
    "",
    "Connection mode selected",
    $("handover").value === "manual"
      ? "Receiving analyses wait for a file transfer; independent work can continue. Click Confirm file transfer at each analyst boundary."
      : "Recorded inputs pass directly to dependent jobs. Each result keeps its inputs and versions.",
  );
  render();
};
$("revise-cpue").onclick = () => {
  $("filter").value = $("filter").value === "0" ? "1200" : "0";
  status(
    "",
    "CPUE A needs an update",
    "Run the revised analysis, then pass its output to assessment.",
  );
  selectJob("cpue_a");
};
async function transferFiles(connect = false) {
  if (!waitingTransfer || confirmingTransfer) return;
  const pending = waitingTransfer, executionMode = mode, version = modeVersion;
  const current = () => waitingTransfer === pending && mode === executionMode &&
    modeVersion === version;
  const confirmation = {
    connect,
    request_id: pending.request_id,
    transfer_count: pending.transfer_count,
  };
  confirmingTransfer = true;
  render();
  try {
    const response = await call("transfer", confirmation);
    if (!current()) return;
    if (response.connected === true) $("handover").value = "connected";
    render();
  } catch (error) {
    if (!current()) return;
    confirmingTransfer = false;
    status(
      "failed",
      "Transfer not confirmed",
      error.message + " Try the transfer again.",
    );
    render();
  }
}
$("transfer-files").onclick = () => transferFiles();
$("connect-workflow").onclick = () => transferFiles(true);
$("reset").onclick = async () => {
  if (!ready || busy || mode !== "cloud" || unresolvedLive) return;
  ++planVersion;
  busy = true;
  status("running", "Starting afresh", "Clearing the live workspace. No new analysis has started.");
  render();
  try {
    const result = await call("reset");
    reproductionChecks.clear();
    completedRun = null;
    records = result.records;
    states = {};
    latestRun = "";
    liveExecutionLink = "";
    $("github-run").hidden = true;
    selected = "submission";
    $("snapshot").value = "2021";
    $("filter").value = "0";
    $("growth-rate").value = "0.30";
    $("mse-buffer").value = "0.8";
    $("run-id").textContent = "";
    messages.length = 0;
    $("execution-log").textContent = "No execution yet.";
    busy = false;
    status(
      "",
      "Ready to run",
      "Run the workflow, then change a setting to see which results update and which are reused.",
    );
    selectJob("submission");
  } catch (error) {
    busy = false;
    status("failed", "Reset unavailable", error.message + " No new analysis has started.");
    render();
  }
};
function renderViewGuide() {
  const orchestration = $("workflow-view").hidden;
  const manual = $("handover").value === "manual" && mode !== "saved";
  $("view-guide-title").textContent = orchestration
    ? manual ? "Follow a manual handover"
    : mode === "saved" ? "Inspect results and their inputs"
    : "Run analyses and follow an update"
    : "Follow results into later analyses";
  $("view-guide-description").textContent = orchestration
    ? manual
      ? "Receiving analyses wait for Confirm file transfer; other ready jobs can continue. Open Output or Record to inspect a result."
      : mode === "saved"
      ? "Explore saved results by task. Open Output to read a result or Record to follow its inputs, code and software."
      : "Run the workflow, change a setting, then choose Update workflow. Affected jobs rerun; unchanged results keep their original records."
    : manual
      ? "Arrows show the results passed between analysts. Confirm each file transfer to continue the receiving analyses."
      : mode === "saved"
      ? "Explore saved results: CPUE indices feed assessments, whose results inform MSE. Open a result, then use Inputs & versions to trace the earlier results it used."
      : "Arrows show which results become inputs. Change a setting and choose Update workflow to follow its effect.";
  $("view-guide-link").href = orchestration ? "#workflow" : "#orchestration";
  $("view-guide-link").textContent = orchestration ? "See workflow diagram →"
    : manual ? "Inspect job outputs →" : "Open Orchestration tool →";
}
function showTab(tab) {
  const orchestration = tab === "jobs";
  for (const button of document.querySelectorAll("[data-tab]")) {
    const active = button.dataset.tab === tab;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
  }
  $("workflow-view").hidden = orchestration;
  $("jobs-view").hidden = !orchestration;
  // One set of controls operates the same workflow from either view.
  if (orchestration) $("workspace-run-controls").append($("run-controls"));
  else $("workflow-view").before($("run-controls"));
  renderViewGuide();
}
function showLinkedTab() {
  showTab(location.hash === "#orchestration" ? "jobs" : "workflow");
}
for (const button of document.querySelectorAll("[data-tab]")) {
  button.onclick = () => {
    location.hash = button.dataset.tab === "jobs" ? "orchestration" : "workflow";
    showTab(button.dataset.tab);
  };
}
window.addEventListener("hashchange", showLinkedTab);
function showRecord(show) {
  $("record-panel").hidden = !show;
  $("record-toggle").textContent = show ? "Hide record" : "Show record";
  $("record-toggle").setAttribute("aria-expanded", show);
}
$("record-toggle").onclick = () => showRecord($("record-panel").hidden);
$("record-close").onclick = () => showRecord(false);
$("all-tasks").onclick = () => {
  selectedTask = "";
  workspaceView = "jobs";
  jobStatusFilter = "";
  $("task-title").textContent = "All jobs";
  render();
};
$("show-tasks").onclick = () => {
  workspaceView = "tasks";
  render();
};
$("show-dependencies").onclick = () => {
  workspaceView = "dependencies";
  render();
};
$("dependency-job").onchange = () => inspectDependencies($("dependency-job").value);
$("running-jobs").onclick = () => {
  workspaceView = "jobs";
  selectedTask = "";
  jobStatusFilter = "running";
  render();
};
$("task-filter").onchange = () => {
  selectedTask = $("task-filter").value;
  render();
};
$("job-status-filter").onchange = () => {
  jobStatusFilter = $("job-status-filter").value;
  render();
};
for (const icon of document.querySelectorAll("[data-workspace-icon]")) {
  icon.append(lineIcon(icon.dataset.workspaceIcon));
}

function download(name, bytes, type) {
  const url = URL.createObjectURL(new Blob([bytes], { type })),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
$("download").onclick = async () => {
  try {
    const bytes = Uint8Array.from(
      atob(mode === "saved" ? payload.saved.bundle : await call("download")),
      (char) => char.charCodeAt(0),
    );
    download("fisheries-workflow-run.zip", bytes, "application/zip");
  } catch (error) {
    status("failed", "Download unavailable", error.message);
  }
};
function displayOutput(title, output, kind = "Job output") {
  if (output.record && !output.comparison) {
    output.comparison = reproductionChecks.get(checkKey(output.record));
  }
  currentOutput = output;
  renderOutputRun();
  $("output-title").textContent = title;
  document.querySelector('[data-output="report"]').textContent =
    (output.record?.job || output.job || "").endsWith("_report") ? "Report" : "Results";
  $("output-kind").textContent = [jobNumber(output.record?.job || output.job), kind]
    .filter(Boolean).join(" · ");
  // Keep saved report bytes intact; narrow screens scroll wide tables locally.
  const reportStyle = `<style>@media(max-width:640px){
    html,body{max-width:100%;overflow-wrap:anywhere}
    body{box-sizing:border-box}
    table,pre{display:block;max-width:100%;overflow-x:auto}
    code{overflow-wrap:anywhere;word-break:break-word}
    svg,img{max-width:100%;height:auto}
    .page-columns{display:block!important}
    main.content{min-width:0;max-width:100%;width:auto!important}
  }</style>`;
  $("output-frame").srcdoc = output.html.replace(/<body\b/i, reportStyle + "<body");
  $("output-frame").hidden = false;
  $("output-json").hidden = true;
  $("output-record").hidden = true;
  document.querySelectorAll("[data-output]").forEach((button) => {
    button.classList.toggle("active", button.dataset.output === "report");
    button.disabled = button.dataset.output !== "report" && !output.record;
  });
  $("output-dialog").showModal();
}
async function openOutput(key) {
  if (!records[key]) {
    const job = byKey[key];
    const page = document.implementation.createHTMLDocument(job.title);
    const content = uiElement("main");
    content.style.cssText = "font:16px/1.6 system-ui;color:#233649;max-width:720px;margin:32px auto;padding:0 24px";
    content.append(uiElement("h1", "", "No output yet"),
      uiElement("p", "", job.description),
      uiElement("p", "", job.parents.length
        ? "Required inputs: " + job.parents.map(jobLabel).join("; ") + "."
        : "Starts with the supplied catch and effort data."),
      uiElement("p", "", "Run this job to produce its output. Missing inputs are prepared first."));
    page.body.append(content);
    displayOutput(job.title, { job: key, html: "<!doctype html>" + page.documentElement.outerHTML }, "Job details");
    return;
  }
  try {
    displayOutput(
      byKey[key].title,
      mode === "saved"
        ? payload.saved.outputs[key]
        : await call("view", { job: key }),
      mode === "saved" ? "Saved example output" : "Job output",
    );
  } catch (error) {
    status("failed", "This output is unavailable", error.message);
  }
}
function renderOutputRun() {
  const key = currentOutput?.record?.job || currentOutput?.job;
  $("output-run").hidden = !key || mode === "saved";
  $("output-run").disabled = !canRequestRun();
  $("output-run").textContent = busy ? "Running…" : "Run this job";
  $("output-run").title = "Run only this job. Prepare missing or changed inputs first.";
}
$("output-run").onclick = () => runFromJob(currentOutput?.record?.job || currentOutput?.job);
$("example").onclick = () =>
  displayOutput(
    "Assessment report",
    { html: payload.example },
    "Preserved example",
  );
$("licences").onclick = () => {
  const pre = document.createElement("pre");
  pre.textContent = payload.notices;
  displayOutput("Sources and licences", {
    html:
      '<!doctype html><meta charset="utf-8"><style>body{padding:24px;font:14px/1.6 system-ui}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style>' +
      pre.outerHTML,
  }, "Preserved software");
};
$("output-close").onclick = () => $("output-dialog").close();
$("output-dialog").onclick = (event) => {
  if (event.target === $("output-dialog")) {
    const box = event.target.getBoundingClientRect();
    if (
      event.clientX < box.left || event.clientX > box.right ||
      event.clientY < box.top || event.clientY > box.bottom
    ) event.target.close();
  }
};
for (const button of document.querySelectorAll("[data-output]")) {
  button.onclick = () => {
    document.querySelectorAll("[data-output]").forEach((other) =>
      other.classList.toggle("active", other === button)
    );
    const report = button.dataset.output === "report";
    const record = button.dataset.output === "record";
    $("output-frame").hidden = !report;
    $("output-record").hidden = !record;
    $("output-json").hidden = report || record;
    if (record) renderRecord();
    else if (!report) {
      $("output-json").textContent = button.dataset.output === "log"
        ? currentOutput.record.log.join("\n")
        : JSON.stringify(
          currentOutput[
            button.dataset.output === "data" ? "output" : "record"
          ],
          null,
          2,
        );
    }
  };
}
$("save-output").onclick = () =>
  download("analysis-output.html", currentOutput.html, "text/html");

function explainMode() {
  $("mode-help").textContent = mode === "cloud"
    ? "Run analyses on GitHub with recorded software."
    : "Browse saved results; does not run code.";
}

async function activateMode(next, { fallbackReason = "", preserveSelection = false } = {}) {
  if (!["cloud", "saved"].includes(next)) throw Error("Choose Live run or View example.");
  if (location.protocol === "file:" && next === "cloud") next = "saved";
  const version = ++modeVersion;
  ++planVersion;
  const selection = { selected, executionScope };
  $("mode-notice").hidden = !fallbackReason;
  if (fallbackReason) $("mode-notice-message").textContent =
    fallbackReason + " The saved example is available. No new analysis has started.";
  modeStates[mode] = {
    records, states, latestRun, selected, executionScope, settingsIntent,
    completedRun, messages: [...messages], settings: settings(),
    handover: $("handover").value,
  };
  mode = next;
  explainMode();
  ready = false;
  plan = null;
  waitingTransfer = null;
  confirmingTransfer = false;
  correctionPending = false;
  activities = {};
  dispatchPending = false;
  $("mode").value = mode;
  $("github-run").hidden = mode !== "cloud" || !liveExecutionLink;
  if (liveExecutionLink) $("github-run").href = liveExecutionLink;
  const saved = modeStates[mode];
  records = saved?.records || {};
  states = saved?.states || {};
  latestRun = saved?.latestRun || "";
  selected = preserveSelection ? selection.selected : saved?.selected || "submission";
  executionScope = preserveSelection ? selection.executionScope : saved?.executionScope || "workflow";
  settingsIntent = saved?.settingsIntent || false;
  $("handover").value = saved?.handover || "connected";
  completedRun = saved?.completedRun || null;
  messages.splice(0, messages.length, ...(saved?.messages || []));
  $("execution-log").textContent = messages.join("\n") || "No execution yet.";
  const values = mode === "saved" ? payload.saved.settings : saved?.settings;
  if (values) {
    $("snapshot").value = values.last_year;
    $("filter").value = values.min_hooks_a;
    $("growth-rate").value = Number(values.growth_rate_2).toFixed(2);
    $("mse-buffer").value = values.mse_buffer ?? 0.8;
  }
  if (mode === "saved") {
    records = payload.saved.records;
    states = Object.fromEntries(jobs.map((job) => [job.key, "complete"]));
    latestRun = "Saved example";
    messages.length = 0;
    payload.saved.events.forEach(log);
    status("", "Saved results", location.protocol === "file:"
      ? `${Object.keys(records).length} completed jobs. Browse their reports and records offline.`
      : `${Object.keys(records).length} completed jobs. Choose Live run to repeat or update the analyses.`);
  } else if (unresolvedLive) {
    showError(Object.assign(Error("The previous live run has an unresolved outcome."), {
      executionUnknown: true,
    }));
  } else {
    status("running", "Connecting to the live run",
      "Checking the live service. The saved example opens if the service is unavailable.");
    $("saved-fallback").hidden = false;
    const slowConnection = setTimeout(() => {
      if (version !== modeVersion || ready) return;
      status("running", "Waiting for the live service",
        "No analysis has started. You can inspect the saved example while waiting.");
      $("saved-fallback").hidden = false;
    }, 3000);
    render();
    try {
      if (!cloudReady) {
        const result = await cloud.initialise();
        cloudReady = true;
        if (version !== modeVersion) return;
        records = result.records;
        states = {};
        latestRun = "";
        completedRun = null;
      }
      if (version !== modeVersion) return;
      ready = true;
      explainMode();
      status("", Object.keys(records).length ? "Your results are still here" : "Ready to run",
        "No login needed. Each run uses the recorded container. Change a setting to compare updated and reused results.");
      await refreshPlan();
    } catch (error) {
      if (version !== modeVersion) return;
      const reason = /8 seconds/.test(error.message)
        ? "The live service did not respond." : "The live service is unavailable.";
      await activateMode("saved", { fallbackReason: reason, preserveSelection: true });
      return;
    } finally {
      clearTimeout(slowConnection);
    }
  }
  $("run-id").textContent = latestRun;
  $("execution-note").textContent = mode === "cloud"
    ? "Live results expire after 10 minutes. Download this run to keep them."
    : "Saved container outputs are included in this HTML file. New runs use the live website.";
  render();
}
$("mode").onchange = () => activateMode($("mode").value);
$("dismiss-mode-notice").onclick = () => { $("mode-notice").hidden = true; };
$("saved-fallback").onclick = () => activateMode("saved", { preserveSelection: true });
$("retry-connection").onclick = () => activateMode("cloud");
if (location.protocol === "file:") $("mode").querySelector('[value="cloud"]').disabled = true;
render();
showLinkedTab();
activateMode(location.protocol === "file:" ? "saved" : "cloud");
