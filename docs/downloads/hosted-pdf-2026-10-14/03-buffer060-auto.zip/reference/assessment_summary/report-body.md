# Compare assessments

Compare the four fitted biomass trajectories.

![](report-plot-01.svg){fig-alt="Biomass / each case's carrying capacity"}

Biomass / each case's carrying capacity

The cases combine two CPUE indices and two fixed growth settings. Their differences are sensitivities, not an uncertainty interval.

  Case            Final year   B / K
  --------------- ------------ --------
  Assessment A1   2021         0.5011
  Assessment A2   2021         0.4891
  Assessment B1   2021         0.4845
  Assessment B2   2021         0.4744

The selected Fiji fleet index is not a validated stock-wide abundance index. Using it with stock-wide catches is a teaching assumption.
