"""Record the behavioural checks; omit execution-time comparisons."""
import hashlib
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class RecordResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.passed = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.passed.append(test.id().split('.')[-1])


def main():
    suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'))
    result = unittest.TextTestRunner(resultclass=RecordResult, verbosity=1).run(suite)
    if not result.wasSuccessful():
        raise SystemExit(1)
    files = [ROOT/'Makefile', ROOT/'workflow/Makefile', ROOT/'workflow/jobs.json', *ROOT.glob('workflow/*.py'), *ROOT.glob('tests/*.py'), *ROOT.glob('cloud/*.py'),
             *ROOT.glob('workflow/r/*.R'), *ROOT.glob('tests/*.R'),
             *(path for path in (ROOT/'jobs').rglob('*') if path.suffix in ('.R', '.qmd'))]
    record = {
        'scope': 'Coordinator doubles and source/runtime boundaries. Actual R/RTMB/Quarto integration runs only when PAPER_NATIVE_INTEGRATION=1. Scientific checks have a separate R report.',
        'checks_passed': result.passed,
        'checks_skipped': [{'test': test.id(), 'reason': reason} for test, reason in result.skipped],
        'source_files': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
        'comparison_tolerances': {'relative': 1e-6, 'absolute': 1e-9},
    }
    path = Path(sys.argv[1] if len(sys.argv) > 1 else '.test-output/behaviour.json')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, indent=2) + '\n')
    print(f'{len(result.passed)} behavioural checks recorded in {path}')


if __name__ == '__main__':
    main()
