# CPUE report (`cpue_report`)

Render the saved CPUE comparison as a Quarto report. The report reads the result and run record without refitting the GLMs.

**Path:** Saved index comparison → describe methods and values → CPUE report.

**Inputs:** `runs/cpue_summary/output.json` and the report job's saved run record.

**From:** [Compare CPUE results (`cpue_summary`)](../cpue_summary/README.md).

**Settings:** No job-specific settings (`{}`).

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=cpue_report CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_report/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_report/record.json)
