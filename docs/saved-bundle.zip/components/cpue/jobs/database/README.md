# Prepare and load (`database`)

Check the accepted records and calculate snapshot coverage in R. The coordinator stores these same records in the SQLite snapshot.

**Path:** Accepted rows → save SQLite snapshot → fixed data inputs.

**Inputs:** QC is the declared scheduling gate. The calculation reads accepted `runs/submission/output.json` rows; the QC result is recorded as the declared parent.

**From:** [Quality check (`qc`)](../qc/README.md).

**Settings:** No job-specific settings (`{}`).

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=database CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/database/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/database/record.json)
