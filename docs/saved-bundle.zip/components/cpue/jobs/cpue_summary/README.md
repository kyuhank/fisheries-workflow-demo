# Compare CPUE results (`cpue_summary`)

Compare the two saved CPUE indices without fitting another model.

**Path:** Indices A and B → align years → index comparison.

**Inputs:** The `series` and method metadata in `runs/cpue_a/output.json` and `runs/cpue_b/output.json`.

**From:** [CPUE analysis A (`cpue_a`)](../cpue_a/README.md), [CPUE analysis B (`cpue_b`)](../cpue_b/README.md).

**Settings:** No job-specific settings (`{}`).

The result preserves both producing methods, prediction support, weights, units and checks. A uses a cell–quarter adjustment; B adjusts for quarter only.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=cpue_summary CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_summary/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_summary/record.json)
