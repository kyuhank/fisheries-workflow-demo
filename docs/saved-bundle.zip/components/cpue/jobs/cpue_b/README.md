# CPUE analysis B (`cpue_b`)

Estimate the alternative annual CPUE index with a year-and-quarter quasipoisson GLM.

**Path:** Catch and effort rows → year-and-quarter GLM → annual CPUE index B.

**Inputs:** The aggregate `sets` rows in `runs/extract/output.json`.

**From:** [Extract data (`extract`)](../extract/README.md).

**Settings:** No job-specific settings (`{}`).

Use the same log(hooks / 1000) offset, prediction support and first-year normalisation as A, with quarter effects instead of cell–quarter effects. Quarter effects partly confound spatial differences on this support. Saved output includes nominal and standardised fish per 1,000 hooks. Synthetic fixtures retain the year-only Poisson example.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=cpue_b CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_b/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_b/record.json)
