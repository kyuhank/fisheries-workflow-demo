# Extract data (`extract`)

Use recorded SQLite queries to select the fixed CPUE support and annual catches.

**Path:** SQLite snapshot → recorded SQL → CPUE rows and annual catches.

**Inputs:** `runs/database/snapshot.sqlite`, [`extract.sql`](https://github.com/kyuhank/fisheries-workflow-demo/blob/0182140326a748a5eae848e9a1e7e568d65bc337/workflow/extract.sql) and [`extract-catch.sql`](https://github.com/kyuhank/fisheries-workflow-demo/blob/0182140326a748a5eae848e9a1e7e568d65bc337/workflow/extract-catch.sql).

**From:** [Prepare and load (`database`)](../database/README.md).

**Settings:** No job-specific settings (`{}`).

CPUE rows retain fleet, year, cell, quarter, hooks and albacore catch in numbers. Annual catch is a separate tonnes series. Released zero counts are retained; absent or suppressed values are not converted to zeros.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=extract CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/extract/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/extract/record.json)
