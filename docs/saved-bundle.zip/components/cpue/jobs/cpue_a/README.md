# CPUE analysis A (`cpue_a`)

Estimate annual CPUE with a quasipoisson GLM adjusting for year and cell–quarter stratum.

**Path:** Catch and effort rows → adjusted GLM → annual CPUE index A.

**Inputs:** The aggregate `sets` rows in `runs/extract/output.json`.

**From:** [Extract data (`extract`)](../extract/README.md).

**Settings:** `min_hooks_a`, recorded as `min_hooks` (default: 0).

Use a log(hooks / 1000) offset. Predict each supported stratum at 1,000 hooks and average on the response scale with equal fixed weights; divide by the first-year mean. The existing 1,200-hook filter excludes no public rows and is hidden in the public-data app. Synthetic fixtures retain the vessel-effect Poisson example.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=cpue_a CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_a/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/cpue_a/record.json)
