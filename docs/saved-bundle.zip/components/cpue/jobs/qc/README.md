# Quality check (`qc`)

Check positive effort, non-negative released catch and unique source-row IDs.

**Path:** Submitted rows → check effort, catch and IDs → accepted rows.

**Inputs:** `runs/submission/output.json`; supplied raw-source rows are available for correction.

**From:** [Data submission (`submission`)](../submission/README.md).

**Settings:** No job-specific settings (`{}`).

A correction replaces the submitted result and producing record. The public example does not insert an artificial error.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=qc CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/qc/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/qc/record.json)
