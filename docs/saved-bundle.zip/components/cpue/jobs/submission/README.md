# Data submission (`submission`)

Select the requested years from the supplied public catch and effort records.

**Path:** Source records → select final year → submitted rows.

**Inputs:** [`data/public-source.json`](../../data/public-source.json), including aggregate fishing rows and the separate annual catch series.

**From:** None.

**Settings:** `last_year` (default: 2021).

The public input preserves released values. The invalid-effort correction cycle is retained only for synthetic fixtures.

Supply this job's saved upstream results in a context JSON, then run from the repository root:

```sh
make run JOB=submission CONTEXT=/absolute/context.json OUT=/absolute/result
```

[run.R](run.R) defines `calculate(context)`; the component adapter loads its local R
library and writes `response.json` with `result` and `effects`. See the
[job guide](../README.md) for context fields, runtime selection and saved-result rendering.

[Saved report](https://kyuhank.github.io/fisheries-workflow-demo/example/submission/report.html) · [Run record](https://kyuhank.github.io/fisheries-workflow-demo/example/submission/record.json)
