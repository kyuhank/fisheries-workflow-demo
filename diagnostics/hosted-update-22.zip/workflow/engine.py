"""Execute selected jobs, verify saved inputs and preserve their original records."""
import asyncio
import hashlib
import io
import json
from pathlib import Path
import platform
import shutil
import shlex
import sqlite3
import sys
import zipfile

from . import reports
from .r_bridge import RBridge
from .quarto_reports import render_report
from .spec import DEFAULTS, SPEC, STAGES, active_spec, downstream, handover_groups

ROOT = Path(__file__).resolve().parents[1]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def read_json(path):
    return json.loads(path.read_text())


def job_files():
    """Executable jobs and their reader guides, without cached bytecode or outputs."""
    return sorted(path for path in (ROOT / 'jobs').rglob('*')
                  if path.is_file() and path.suffix in ('.md', '.R', '.qmd'))


def calculation_files():
    """The actual shared R sources and JSON driver shipped with the calculation container."""
    return sorted([ROOT / 'workflow/r_driver.R', *(ROOT / 'workflow/r').glob('*.R')])


class Workflow:
    def __init__(self, directory='runs', notify=None, pause=0, before_job=None,
                 manual_transfer=None, r_bridge=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.notify = notify or (lambda event: None)
        self.pause = pause
        self.before_job = before_job
        self.manual_transfer = manual_transfer
        self.calculator = r_bridge or RBridge()
        self.settings = dict(DEFAULTS)
        self.records = {}
        self.events = []
        self.run_number = 0
        self.last_plan = None
        self.running = False
        self.execution = {}
        state = self.directory / 'state.json'
        if state.exists():
            previous = read_json(state)
            if 'mortality_2' in previous.get('settings', {}):
                raise ValueError('This checkpoint uses the earlier age-model version. '
                                 'Keep its saved results and start a fresh v1.8 R session.')
            self.records = previous['records']
            self.settings = {**DEFAULTS, 'mse': False, **previous['settings']}
            self.run_number = previous['run_number']
            self.last_plan = previous.get('last_plan')

    def configure(self, settings):
        candidate = {**self.settings, **settings}
        if set(candidate) != set(DEFAULTS):
            raise ValueError('Unknown analysis setting.')
        if candidate['last_year'] not in (2021, 2022, 2023, 2024):
            raise ValueError('Select a supplied data snapshot.')
        if candidate['min_hooks_a'] not in (0, 1200):
            raise ValueError('Select one of the supplied CPUE filters.')
        if candidate['growth_rate_2'] not in (0.25, 0.30, 0.35):
            raise ValueError('Select one of the supplied intrinsic-growth settings.')
        if type(candidate['mse']) is not bool:
            raise ValueError('Select whether to include the MSE analyses.')
        if (type(candidate['mse_buffer']) not in (int, float) or
                candidate['mse_buffer'] not in (0.6, 0.8, 1.0)):
            raise ValueError('Select one of the supplied MSE catch buffers.')
        self.settings = candidate

    @property
    def spec(self):
        return active_spec(self.settings)

    def output(self, key):
        return read_json(self.directory / key / 'output.json')

    def job_settings(self, key):
        if key == 'submission':
            return {'last_year': self.settings['last_year']}
        if key == 'cpue_a':
            return {'min_hooks': self.settings['min_hooks_a']}
        if key in ('assessment_a2', 'assessment_b2'):
            return {'r': self.settings['growth_rate_2']}
        if key in ('assessment_a1', 'assessment_b1'):
            return {'r': 0.25}
        if key == 'mse_buffered':
            return {'buffer': self.settings['mse_buffer']}
        return {}

    def code_record(self, key):
        names = ['workflow/engine.py', 'workflow/spec.py', 'workflow/reports.py',
                 'workflow/r_bridge.py', 'workflow/r_driver.R',
                 'workflow/quarto_reports.py', f'jobs/{key}/run.R']
        names += [path.relative_to(ROOT).as_posix() for path in (ROOT / 'workflow/r').glob('*.R')]
        if key in ('cpue_report', 'assessment_report', 'mse_report'):
            names.append(f'jobs/{key}/report.qmd')
        if key == 'extract':
            names += ['workflow/extract.sql', 'workflow/extract-catch.sql']
        return {name: digest((ROOT / name).read_bytes()) for name in names}

    def signature(self, key):
        parents = {parent: {'signature': self.records.get(parent, {}).get('signature'),
                            'outputs': self.records.get(parent, {}).get('outputs')}
                   for parent in SPEC[key]['parents']}
        material = {'code': self.code_record(key), 'settings': self.job_settings(key),
                    'parents': parents, 'software': self.software()}
        if key == 'submission':
            material['data'] = {name: digest((ROOT / 'data' / name).read_bytes())
                                for name in ['fishery.sqlite', 'submission.json', 'scenario.json', 'source-data.json', 'generation.json'] if (ROOT / 'data' / name).is_file()}
        return digest(encoded(material))

    def software(self):
        return {**self.calculator.software(),
                'python': platform.python_version(), 'platform': sys.platform,
                'runtime': 'Rscript (container)', 'adapter_runtime': 'CPython',
                'sqlite': sqlite3.sqlite_version}

    def valid(self, key):
        record = self.records.get(key)
        if not record or record['signature'] != self.signature(key):
            return False
        return all((self.directory / key / name).is_file()
                   and digest((self.directory / key / name).read_bytes()) == checksum
                   for name, checksum in record['outputs'].items())

    def plan(self, start, scope='workflow'):
        spec = self.spec
        if start not in spec:
            raise ValueError('Unknown starting job.')
        if scope not in ('workflow', 'job'):
            raise ValueError('Select job or workflow execution.')
        changed = [key for key in spec if not self.valid(key)]
        if scope == 'workflow':
            selected = downstream([start, *changed], spec)
        else:
            required = set()

            def include_inputs(key):
                if key in required:
                    return
                required.add(key)
                for parent in spec[key]['parents']:
                    include_inputs(parent)

            include_inputs(start)
            selected = []
            for key, job in spec.items():
                if key in required and (key == start or key in changed or
                                        any(parent in selected for parent in job['parents'])):
                    selected.append(key)
        return {'run': selected,
                'retained': [key for key in spec if key not in selected and key in self.records],
                'changed': changed, 'start': start, 'scope': scope}

    def record_event(self, key, state, message, **details):
        event = {'job': key, 'state': state, 'message': message, **details}
        self.events.append(event)
        self.notify({**event, 'record': self.records.get(key)})

    async def emit(self, key, state, message, **details):
        self.record_event(key, state, message, **details)
        if self.pause and state in ('running', 'failed', 'returned', 'received'):
            await asyncio.sleep(self.pause)

    def source_context(self):
        """Read source bytes; year selection and the QC example are R jobs."""
        if hasattr(self, 'hosted_data'):
            return {**json.loads(json.dumps(self.hosted_data)), 'submission': None}
        with sqlite3.connect(f'file:{ROOT / "data/fishery.sqlite"}?mode=ro', uri=True) as db:
            db.row_factory = sqlite3.Row
            rows = [dict(r) for r in db.execute('SELECT * FROM sets ORDER BY year,set_id')]
            catch = [dict(r) for r in db.execute('SELECT * FROM removals ORDER BY year')]
        return {'sets': rows, 'catch': catch, 'submission': read_json(ROOT / 'data/submission.json')}

    def extracted_context(self):
        sql = (ROOT / 'workflow/extract.sql').read_text()
        catch_sql = (ROOT / 'workflow/extract-catch.sql').read_text()
        with sqlite3.connect(self.directory / 'database/snapshot.sqlite') as db:
            db.row_factory = sqlite3.Row
            return {'sets': [dict(r) for r in db.execute(sql)],
                    'catch': [dict(r) for r in db.execute(catch_sql)], 'sql': sql + '\n' + catch_sql}

    def store_snapshot(self, data):
        """The storage adapter loads accepted R-checked rows into real SQLite."""
        folder = self.directory / 'database'
        folder.mkdir(exist_ok=True)
        dbfile = folder / 'snapshot.sqlite'
        dbfile.unlink(missing_ok=True)
        with sqlite3.connect(dbfile) as db:
            db.execute('CREATE TABLE sets(set_id TEXT PRIMARY KEY,year INTEGER,vessel TEXT,hooks INTEGER CHECK(hooks>0),catch_n INTEGER CHECK(catch_n>=0))')
            db.execute('CREATE TABLE removals(year INTEGER PRIMARY KEY,catch_t REAL CHECK(catch_t>=0))')
            db.executemany('INSERT INTO sets VALUES(?,?,?,?,?)', [[row[name] for name in ('set_id','year','vessel','hooks','catch_n')] for row in data['sets']])
            db.executemany('INSERT INTO removals VALUES(?,?)', [[row['year'],row['catch_t']] for row in data['catch']])

    def save(self, key, result, run_id):
        folder = self.directory / key
        folder.mkdir(exist_ok=True)
        (folder / 'output.json').write_bytes(encoded(result))
        outputs = {'output.json': digest((folder / 'output.json').read_bytes())}
        if key == 'database':
            outputs['snapshot.sqlite'] = digest((folder / 'snapshot.sqlite').read_bytes())
        record = {'job': key, 'owner': SPEC[key]['owner'], 'run_id': run_id,
                  'signature': self.signature(key), 'settings': self.job_settings(key),
                  'snapshot': self.settings['last_year'], 'code': self.code_record(key),
                  'software': self.software(), 'outputs': outputs,
                  'log': [e['message'] for e in self.events if e['job'] == key or
                          (e['state'] in ('handover', 'received') and key in e.get('group', []))]
                         + [SPEC[key]['title'] + ' complete.'],
                  'inputs': {parent: {'run_id': self.records[parent]['run_id'],
                                      'checksum': self.records[parent]['outputs']['output.json']}
                             for parent in SPEC[key]['parents']}}
        if self.execution:
            record['execution'] = dict(self.execution)
        build = ROOT / 'build-info.json'
        if build.exists():
            record['source'] = read_json(build)
        if self.execution.get('commit'):
            record['source'] = {'repository': 'https://github.com/' + self.execution['repository'],
                                'commit': self.execution['commit']}
        record['data_files'] = {name: digest((ROOT / 'data' / name).read_bytes())
                                for name in ['fishery.sqlite', 'submission.json', 'scenario.json', 'source-data.json', 'generation.json'] if (ROOT / 'data' / name).is_file()}
        self.records[key] = record
        lineage = [{'job': SPEC[parent]['title'], **details} for parent, details in record['inputs'].items()]
        page = reports.output_page(SPEC[key], result, record, lineage)
        rendered = render_report(ROOT, key, result, record, folder, page)
        record['report_rendering'] = rendered
        record['outputs']['report.html'] = digest((folder / 'report.html').read_bytes())
        if rendered['quarto_executed']:
            for name in ('report.qmd', 'report-data.json'):
                record['outputs'][name] = digest((folder / name).read_bytes())
        (folder / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
        self.persist()

    def persist(self):
        (self.directory / 'state.json').write_bytes(encoded(self.state()))

    def state(self):
        return {'settings': self.settings, 'records': self.records,
                'run_number': self.run_number, 'last_plan': self.last_plan,
                'jobs': list(self.spec.values()), 'events': self.events}

    async def calculate(self, key, run_id):
        if key not in SPEC:
            raise ValueError('No calculation registered for this job.')
        parents = {parent: self.output(parent) for parent in SPEC[key]['parents']}
        if key == 'database':
            parents['submission'] = self.output('submission')
        context = {'key': key, 'settings': self.settings, 'job_settings': self.job_settings(key),
                   'run_id': run_id, 'parents': parents}
        if key in ('submission', 'qc'):
            context['source'] = self.source_context()
        if key == 'extract':
            context['extracted'] = self.extracted_context()
        response = await self.calculator.calculate(context)
        result, effects = response['result'], response['effects']
        if effects:
            if key != 'qc' or set(effects) != {'resubmit_submission'}:
                raise ValueError('The R job requested undeclared workflow side effects.')
            await self.emit('qc', 'failed', 'Zero effort found. Return the record to the data provider.')
            await self.emit('submission', 'returned', 'The provider corrects the effort field.')
            await self.emit('submission', 'running', 'The provider resubmits the corrected records.', activity='resubmit')
            self.save('submission', effects['resubmit_submission'], run_id)
            await self.emit('submission', 'complete', 'Corrected submission received.')
            await self.emit('qc', 'running', 'Check the corrected submission.')
        if key == 'database':
            self.store_snapshot(parents['submission'])
        return result

    async def run(self, start='submission', scope='workflow'):
        if self.running:
            raise ValueError('An execution is already in progress.')
        self.running = True
        self.events = []
        try:
            plan = self.plan(start, scope)
            self.last_plan = plan
            self.run_number += 1
            run_id = f'Run {self.run_number:03d}'
            self.notify({'state':'plan', **plan, 'run_id':run_id})
            stages = [[key for key in stage if key in plan['run']] for stage in STAGES]
            stages = [keys for keys in stages if keys]
            stage_for = {key: index for index, keys in enumerate(stages) for key in keys}
            tasks = {}
            transfer_lock = asyncio.Lock()

            async def run_stage(index, keys):
                parents = {stage_for[parent] for key in keys for parent in SPEC[key]['parents']
                           if parent in stage_for and stage_for[parent] != index}
                await asyncio.gather(*(tasks[parent] for parent in parents))
                for handover in handover_groups(keys, plan['run']):
                    # Only transfers share this gate; independent reporting keeps
                    # running while a recipient waits for its input files.
                    async with transfer_lock:
                        if self.manual_transfer is None:
                            break
                        recipients = ' and '.join(SPEC[key]['title'] for key in handover['group'])
                        key = handover['group'][0]
                        self.record_event(key, 'handover',
                                          f'Updated inputs are ready for {recipients}. '
                                          'Click Confirm file transfer to continue.', **handover)
                        connected = await self.manual_transfer(handover)
                        await self.emit(key, 'received',
                                        f'File transfer confirmed for {recipients}.', **handover)
                        if connected:
                            self.manual_transfer = None
                for key in keys:
                    if self.before_job:
                        await self.before_job(key)
                for key in keys:
                    self.record_event(key, 'running', SPEC[key]['description'], group=keys)
                if self.pause:
                    await asyncio.sleep(self.pause)
                results = await asyncio.gather(
                    *(self.calculate(key, run_id) for key in keys), return_exceptions=True)
                failures = []
                for key, result in zip(keys, results):
                    try:
                        if isinstance(result, BaseException):
                            raise result
                        self.save(key, result, run_id)
                    except Exception as error:
                        self.records.pop(key, None)
                        self.persist()
                        await self.emit(key, 'failed', str(error))
                        failures.append(error)
                    else:
                        await self.emit(key, 'complete', SPEC[key]['title'] + ' complete.')
                if failures:
                    raise failures[0]
            for index, keys in enumerate(stages):
                tasks[index] = asyncio.create_task(run_stage(index, keys))
            outcomes = await asyncio.gather(*tasks.values(), return_exceptions=True)
            for outcome in outcomes:
                if isinstance(outcome, BaseException):
                    raise outcome
            self.persist()
            return {'run_id':run_id, **plan, **self.state()}
        finally:
            self.running = False

    def bundle(self):
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
            files = [*ROOT.glob('workflow/*.py'), *ROOT.glob('workflow/*.sql'), *ROOT.glob('data/*'),
                     *calculation_files()]
            files += list(ROOT.glob('tests/*.py')) + list(ROOT.glob('tests/*.R'))
            files += list(ROOT.glob('cloud/*.py'))
            files += [ROOT / 'scripts/generate-data.R', ROOT / 'scripts/import-r-data.py']
            files += job_files()
            files += [ROOT / 'ADAPT.md', ROOT / 'cloud/README.md']
            files += [ROOT / name for name in ['run.py','verify.py','Makefile','Dockerfile','README.md','LICENSE','THIRD_PARTY.md','build-info.json'] if (ROOT / name).exists()]
            files += list(ROOT.glob('vendor/analysis/*'))
            checksums = {}
            for path in files:
                name = str(path.relative_to(ROOT)); data = path.read_bytes()
                archive.writestr(name, data); checksums[name] = digest(data)
            for path in self.directory.rglob('*'):
                if path.is_file():
                    name = 'reference/' + str(path.relative_to(self.directory))
                    data = path.read_bytes()
                    archive.writestr(name, data); checksums[name] = digest(data)
            job_target = (self.last_plan or {}).get('start') if (self.last_plan or {}).get('scope') == 'job' else None
            bundle_settings = dict(self.settings)
            if job_target:
                # Form changes made after execution do not change the saved job.
                bundle_settings = read_json(self.directory / 'state.json')['settings']
            if 'mse_buffered' in self.records:
                # A planned but unexecuted control change is not the setting of
                # the downloaded result. Historical records used the default.
                bundle_settings['mse_buffer'] = self.records['mse_buffered']['settings'].get(
                    'buffer', DEFAULTS['mse_buffer'])
            settings = encoded(bundle_settings)
            archive.writestr('settings.json', settings)
            checksums['settings.json'] = digest(settings)
            archive.writestr('SHA256SUMS.json', json.dumps(checksums, indent=2))
            software = self.software()
            image = software['container']
            url_env = (' --env ' + shlex.quote('PAPER_RUNTIME_IMAGE_URL=' + software['container_url'])
                       if software.get('container_url') else '')
            pull = 'docker pull --platform linux/amd64 ' + image
            run = ('docker run --rm --network none --platform linux/amd64 --env PAPER_RUNTIME_IMAGE=' + image
                   + url_env + ' --volume "$PWD:/workspace" --workdir /workspace ' + image
                   + ' python3 run.py --settings settings.json --output reproduced')
            check = ('docker run --rm --network none --platform linux/amd64 --env PAPER_RUNTIME_IMAGE=' + image
                     + url_env + ' --volume "$PWD:/workspace" --workdir /workspace ' + image
                     + ' python3 verify.py reference reproduced')
            note = ''
            if job_target:
                run += f' --from {job_target} --scope job'
                check += f' --job {job_target}'
                note = (f'This check compares only {job_target}. Other saved results retain their earlier '
                        'records and may use earlier inputs; they are not reproduced by this command.\n')
            archive.writestr('REPRODUCE.txt', f'Pull: {pull}\nRun: {run}\nCheck: {check}\n{note}'
                            'New calculations run only in Docker: Rscript executes the R job scripts, Python '
                            'coordinates jobs and SQLite, and Quarto renders the three report jobs. The offline '
                            'page displays saved outputs. Software details, actual container digest and original '
                            'run identities are in reference/state.json.\n')
        return buffer.getvalue()
