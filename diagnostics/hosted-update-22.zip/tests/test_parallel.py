"""Hosted event/transfer tests with explicit coordinator doubles; no scientific execution."""
import asyncio
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ.setdefault('PAPER_REQUEST_ID', '00000000-0000-4000-8000-000000000001')
from cloud.run import HostedWorkflow, PARALLEL_JOBS, EventDelivery
from workflow.engine import Workflow
from tests.coordinator_fixtures import CoordinatorBridge, test_report
from workflow.spec import SPEC, STAGES
from verify import compare


class HostedProcessesTest(unittest.TestCase):
    def test_live_events_preserve_peer_barriers_and_manual_reporting_on_partial_rerun(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = object.__new__(HostedWorkflow)
            Workflow.__init__(runner, directory, notify=runner.publish,
                              manual_transfer=runner.handover, r_bridge=CoordinatorBridge())
            runner.hosted_data = {'sets': [], 'catch': []}
            runner.calculate = Workflow.calculate.__get__(runner)
            runner.pool, runner.transfer_count, runner.delivery = None, 0, EventDelivery()
            delivered, confirmed = [], set()

            def api(path, body=None):
                if path == 'event':
                    delivered.append(json.loads(json.dumps(body)))
                    return {'ok': True}
                self.assertEqual(path, 'control')
                handover = next(item['event'] for item in reversed(delivered)
                                if item['event']['state'] == 'handover')
                boundary = handover['boundary']
                report = {'cpue': 'cpue_report', 'assessment': 'assessment_report'}.get(boundary)
                if boundary == 'data' or any(item['event'].get('job') == report
                                             and item['event']['state'] == 'complete'
                                             for item in delivered):
                    confirmed.add(boundary)
                return {'transfer_count': len(confirmed), 'connected': False}

            with patch('cloud.run.api', side_effect=api), patch('builtins.print'), \
                 patch('workflow.engine.reports.output_page', return_value='TEST DOUBLE'), \
                 patch('workflow.engine.render_report', side_effect=test_report):
                full = asyncio.run(runner.run())
                retained = {key: runner.records[key].copy() for key in
                            ['cpue_b', 'prepare_b', 'assessment_b1', 'assessment_b2']}
                self.assertEqual([item['event']['group'] for item in delivered
                                  if item['event']['state'] == 'handover'],
                                 [['cpue_a', 'cpue_b'], ['prepare_a', 'prepare_b'], ['mse_prepare']])
                self.assert_event_barriers(full['events'])
                self.assert_reporting_before_transfer(full['events'])
                for _ in range(2):
                    delivered.clear(); confirmed.clear()
                    runner.transfer_count = 0
                    runner.configure({'min_hooks_a': 1200})
                    partial = asyncio.run(runner.run('cpue_a'))
                    self.assertEqual([item['event']['group'] for item in delivered
                                      if item['event']['state'] == 'handover'],
                                     [['prepare_a'], ['mse_prepare']])
                    self.assertEqual({key: runner.records[key] for key in retained}, retained)
                    self.assertEqual(len(partial['run']), 14)
                    self.assert_event_barriers(partial['events'])
                    self.assert_reporting_before_transfer(partial['events'])
                    self.assertTrue(all(runner.valid(key) for key in SPEC))

    def assert_reporting_before_transfer(self, events):
        for boundary in ('cpue', 'assessment'):
            report = next(i for i, event in enumerate(events)
                          if event['job'] == boundary + '_report' and event['state'] == 'complete')
            confirmed = next(i for i, event in enumerate(events)
                             if event['state'] == 'received' and event['boundary'] == boundary)
            self.assertLess(report, confirmed)

    def assert_event_barriers(self, events):
        positions = {(event['job'], event['state']): i for i, event in enumerate(events)}
        for group in STAGES:
            completed = [positions[(key, 'complete')] for key in group
                         if (key, 'complete') in positions]
            for key, job in SPEC.items():
                if completed and set(job['parents']).intersection(group) and (key, 'running') in positions:
                    self.assertLess(max(completed), positions[(key, 'running')])



if __name__ == '__main__':
    unittest.main()
